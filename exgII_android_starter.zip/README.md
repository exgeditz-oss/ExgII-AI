# exgII Android App

Starter Android project for the exgII AI assistant.

## Open
Open this folder in Android Studio and let Gradle sync.

## Current
- exgII dark chat UI
- message list
- send button
- clean Android structure

## Next
Connect a secure backend/API for real AI responses, then add image and video generation.
Do not put a secret API key directly inside the APK; users can extract it.
