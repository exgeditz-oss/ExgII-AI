package com.exgii.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Message(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExgIIApp() }
    }
}

@Composable
fun ExgIIApp() {
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf(Message("Hi! Main exgII hoon. 👋", false)))
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF101014),
            surface = Color(0xFF18181E),
            primary = Color(0xFF9B87F5)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(12.dp)
            ) {
                Text("exgII", fontSize = 28.sp, color = Color.White)
                Text("Your AI assistant", color = Color.LightGray)

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                            horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .widthIn(max = 310.dp)
                                    .background(
                                        if (msg.fromUser) Color(0xFF51438A) else Color(0xFF202027),
                                        RoundedCornerShape(18.dp)
                                    )
                                    .padding(13.dp)
                            ) {
                                Text(msg.text, color = Color.White)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message exgII...") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val text = input.trim()
                        if (text.isNotEmpty()) {
                            messages = messages + Message(text, true) +
                                Message("API connect karne ke baad main tumhe real AI response dunga. 🚀", false)
                            input = ""
                        }
                    }) {
                        Text("Send")
                    }
                }
            }
        }
    }
}
